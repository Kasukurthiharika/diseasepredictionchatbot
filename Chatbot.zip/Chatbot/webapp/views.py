
from django.shortcuts import render, redirect
from django.http import HttpResponse, request
from .models import users
from .models import chat
from .models import *
from django.core import serializers
from django.template import Context
import numpy as np
import xlrd
import matplotlib.pyplot as plt;
from django.utils.html import format_html_join


def home(request):
	return render(request, 'index.html')
def userhomedef(request):
	if "useremail" in request.session:
		uid=request.session["useremail"]
		d=users.objects.filter(email__exact=uid)
		return render(request, 'user_home.html',{'data': d[0]})

	else:
		return render(request, 'user.html')

	
def adminhomedef(request):
	if "adminid" in request.session:
		uid=request.session["adminid"]
		return render(request, 'admin_home.html')

	else:
		return render(request, 'admin.html')

	
def training(request):
	if "adminid" in request.session:
		uid=request.session["adminid"]
		return render(request, 'training.html')

	else:
		return render(request, 'admin.html')
def testingpage(request):
	if "adminid" in request.session:
		uid=request.session["adminid"]
		return render(request, 'testing.html')

	else:
		return render(request, 'admin.html')

	

def userlogoutdef(request):
	try:
		del request.session['useremail']
	except:
		pass
	return render(request, 'user.html')
def adminlogoutdef(request):
	try:
		del request.session['adminid']
	except:
		pass
	return render(request, 'admin.html')	
	
def adminlogindef(request):
	return render(request, 'admin.html')

def userlogindef(request):
	return render(request, 'user.html')

def signupdef(request):
	return render(request, 'signup.html')
def usignupactiondef(request):
	email=request.POST['mail']
	pwd=request.POST['pwd']
	zip=request.POST['zip']
	name=request.POST['name']
	age=request.POST['age']
	gen=request.POST['gen']

		
	d=users.objects.filter(email__exact=email).count()
	if d>0:
		return render(request, 'signup.html',{'msg':"Email Already Registered"})
	else:
		d=users(name=name,email=email,pwd=pwd,zip=zip,gender=gen,age=age)
		d.save()
		return render(request, 'signup.html',{'msg':"Register Success, You can Login.."})

	return render(request, 'signup.html',{'msg':"Register Success, You can Login.."})
def userloginactiondef(request):
	if request.method=='POST':
		uid=request.POST['mail']
		pwd=request.POST['pwd']
		d=users.objects.filter(email__exact=uid).filter(pwd__exact=pwd).count()
		
		if d>0:
			d=users.objects.filter(email__exact=uid)
			request.session['useremail']=uid
			request.session['username']=d[0].name
			return render(request, 'user_home.html',{'data': d[0]})

		else:
			return render(request, 'user.html',{'msg':"Login Fail"})

	else:
		return render(request, 'user.html')
def adminloginactiondef(request):
	if request.method=='POST':
		uid=request.POST['uid']
		pwd=request.POST['pwd']
		
		if uid=='admin' and pwd=='admin':
			request.session['adminid']='admin'
			return render(request, 'admin_home.html')

		else:
			return render(request, 'admin.html',{'msg':"Login Fail"})

	else:
		return render(request, 'admin.html')




def addq(request):
    if "adminid" in request.session:
        d = queries.objects.all()
        
        return render(request, 'queries.html', {'data': d})

    else:
        return render(request, 'admin.html')

def addquery(request):
	q=request.POST['q']
	a=request.POST['a']
	
		
	d=queries(q_n=q,an_s=a)
	d.save()
	
	d = queries.objects.all()
	return render(request, 'queries.html', {'data': d,'msg':'Query Added.'})



def chatpage(request):
	
	chat.objects.all().delete()
	d=chat.objects.filter().all()
	return render(request, 'chat.html',{'data': d})


def chataction(request):
	message=request.POST['message']
	uemail=request.session["useremail"]
	uname=request.session["username"]
	d=chat(name='user',email=uemail,message=message)
	d.save()


	ans='Sorry, Not Understood'

	cid=tf.calc(message)
	if cid!=-1:
		d=queries.objects.filter(id__exact=cid)
		for d1 in d:
			ans=d1.an_s

		d=chat(name='chatbot',email='chatbot',message=ans)
		d.save()

		d=chat.objects.filter().all()
		return render(request, 'chat.html',{'data': d})

	cid=tf2.calc(message)
	if cid!=-1:
		d=dataset.objects.filter(id__exact=cid)
		for d1 in d:
			ans=d1.ans

		r=Prediction.do(message)
		r=r.replace('-','//')
		#r='E://Django//Chatbot//'+r+'.htm'
		r=r+'.htm'
		print(r)
		request.session['webp']=r


		d=chat(name='chatbot',email='chatbot',message=ans)
		d.save()

		d=chat.objects.filter().all()
		return render(request, 'chat.html',{'data': d,'bt':True})
	else:

		d=chat(name='chatbot',email='chatbot',message=ans)
		d.save()

		d=chat.objects.filter().all()
		return render(request, 'chat.html',{'data': d})


		
		


	
	
	

def moredetails(request):

	r=request.session['webp']
	#import webbrowser
	#webbrowser.open(r)
	return render(request, r)


