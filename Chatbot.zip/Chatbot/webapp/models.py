from django.db import models
# Create your models here.


class users(models.Model):
	name=models.CharField(max_length=100);
	email=models.CharField(max_length=100);
	pwd=models.CharField(max_length=100);
	zip=models.CharField(max_length=100);
	gender=models.CharField(max_length=100);
	age=models.CharField(max_length=100);
	statu=models.CharField(max_length=100);

class queries(models.Model):
	q_n=models.CharField(max_length=1000);
	an_s=models.CharField(max_length=1000);

class chat(models.Model):
	name=models.CharField(max_length=100);
	email=models.CharField(max_length=100);
	message=models.CharField(max_length=100);